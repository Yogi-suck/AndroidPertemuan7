package id.ac.amikom.motor

import android.content.Context
import android.content.SharedPreferences

class SharedPref(context: Context) {
    private val read: SharedPreferences =
        context.getSharedPreferences(BuildConfig.APPLICATION_ID, Context.MODE_PRIVATE)
    private val write: SharedPreferences.Editor = read.edit()

    fun setNightModeState(state: Boolean?) {
        val editor = read.edit()
        editor.putBoolean("NIGHT MODE", state!!)
        editor.commit()
    }

    fun loadNightModeState(): Boolean? {
        return read.getBoolean("NIGHT MODE", false)
    }

    fun setData(key: String, value: Any?) {
        when (value) {
            is Boolean -> write.putBoolean(key, value)
            is Float -> write.putFloat(key, value)
            is Int -> write.putInt(key, value)
            is Long -> write.putLong(key, value)
            is String -> write.putString(key, value)

        }
        write.commit()
    }

    fun getBoolean(key: String, dafault: Boolean = false) = read.getBoolean(key, dafault)
    fun getFloat(key: String, dafault: Float = 0f) = read.getFloat(key, dafault)
    fun getInt(key: String, dafault: Int = 0) = read.getInt(key, dafault)
    fun getLong(key: String, dafault: Long = 0) = read.getLong(key, dafault)
    fun getString(key: String, dafault: String? = null) = read.getString(key, dafault)

    companion object {
        const val GRID_LAYOUT = "grid_layout"
        const val PABRIKAN = "pabrikan"
        const val APP_NAME = "app_name"
        const val COLUMN = "column"
        const val NAMA_GAMBAR = "nama_gambar"
        const val GAMBAR = "gambar"
        const val CARDVIEW = "cardview"
    }

    var gridLayout: Boolean
    set(value) = setData(GRID_LAYOUT, value)
    get() = getBoolean(GRID_LAYOUT)

    var pabrikan: Boolean
    set(value) = setData(PABRIKAN,value)
    get() = getBoolean(PABRIKAN)

    var appName: String?
    set(value) = setData(APP_NAME,value)
    get() = getString(APP_NAME)

    var column: Int
    set(value) = setData(COLUMN,value)
    get() = getInt(COLUMN)

    var namaGambar: Boolean
    set(value) = setData(NAMA_GAMBAR,value)
    get() = getBoolean(NAMA_GAMBAR)

    var gambar: Boolean
    set(value) = setData(GAMBAR,value)
    get() = getBoolean(GAMBAR)

    var cardview: Boolean
    set(value) = setData(CARDVIEW,value)
    get() = getBoolean(CARDVIEW)
}