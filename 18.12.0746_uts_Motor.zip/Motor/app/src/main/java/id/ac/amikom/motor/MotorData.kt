package id.ac.amikom.motor

object MotorData {
    val list : ArrayList<Motor>
        get() {
            val list : ArrayList<Motor> = arrayListOf()
            list.add(Motor(
                nama = "Burgman Street",
                pabrikan = "Suzuki",
                keterangan = " Suzuki sedang gencar-gencarnya merilis motor baru di Indonesia. Setelah sebelumnya merilis GSX150 Bandit dan Nex II, maka pada tahun 2020 mereka akan meluncurkan Suzuki Burgman Street yang terlebih dahulu dipasarkan di Indonesia. Nantinya motor ini akan menantang Maxi Skuter dari Honda dan Yamaha dengan harga lebih terjangkau dan teknologi tak kalah canggih.",
                url = "https://www.otomotifer.com/motor-terbaru-2019-di-indonesia/",
                gambar = "https://www.otomotifer.com/wp-content/uploads/2018/12/Suzuki-Burgman-Street.jpg"
            ))

            list.add(Motor(
                nama = "FreeGo",
                pabrikan = "Yamaha",
                keterangan = " Apabila mencari motor matic terbaru 2020, maka kami saranka membeli Yamaha FreeGo. Motor terbaru 2020 ini tersedia dalam 3 varian berbeda. Dimana yang tertinggi sudah dilengkapi sistem pengereman ABS dan sistem penguncian Keyless. Harga motor terbaru 2020 ini juga cukup terjangkau dan bisa menjadi alternatif selain Honda Vario 125.",
                url = "https://www.otomotifer.com/motor-terbaru-2019-di-indonesia/",
                gambar = "https://www.otomotifer.com/wp-content/uploads/2018/11/Harga-Motor-Matic-Yamaha-FreeGo-ABS.jpg"
            ))

            list.add(Motor(
                nama = "GSX-R250",
                pabrikan = "Suzuki",
                keterangan = " Suzuki GSX-250R sudah dirilis sejak lama. Namun sayangnya motor 2 Silinder tersebut belum dipasarkan di Indonesia. Padahal motor ini bisa bersaing melawan Honda CBR250RR dan Kawasaki Ninja 250 yang sama-sama dibekali mesin 2 Silinder. Kabarnya Suzuki enggan merilisnya dikarenakan mereka sedang menyiapkan Suzuki GSX-R150 yang desainnya lebih keren dan performa mesin 2 Silidernya lebih bertenaga.",
                url = "https://www.otomotifer.com/motor-terbaru-2019-di-indonesia/",
                gambar = "https://www.otomotifer.com/wp-content/uploads/2018/12/Suzuki-GSX-R250.jpg"
            ))

            list.add(Motor(
                nama = "MT-15",
                pabrikan = "Yamaha",
                keterangan = " Kami yakin Yamaha MT-15 menjadi motor terbaru yang paling ditunggu-tunggu pecinta otomotif tanah air. Motor sport ini menawarkan desain agresif dan ditenagai mesin 1 Silinder 155cc berteknologi VVA sama seperti yang dipakai Yamaha R15 dan Vixion R. Yamaha juga melengkapinya dengan beragam fitur kekinian diantaranya adalah Upside Down, Speedometer Full Digital, dan Assist & Slipper Clutch.",
                url = "https://www.otomotifer.com/motor-terbaru-2019-di-indonesia/",
                gambar = "https://www.otomotifer.com/wp-content/uploads/2018/12/Motor-Terbaru-2019-di-Indonesia.jpg"
            ))

            list.add(Motor(
                nama = "MX King 150 Facelift",
                pabrikan = "Yamaha",
                keterangan = " Motor terbaru ini sudah resmi di rilis di Vietnam, dan kemungkinan besar akan segera dipasarkan di Indonesia pada tahun 2020. Yang menarik dari MX King 150 Facelift adalah sudah dilengkapi headlamp baru dengan lampu LED. Panel meternya juga berubah menjadi Full Digital. Lalu ada pula penambahan fitur Engine Cut Off dan setang sebelah kanan dan saklar pass beam di seteng dibagian kiri.",
                url = "https://www.otomotifer.com/motor-terbaru-2019-di-indonesia/",
                gambar = "https://www.otomotifer.com/wp-content/uploads/2018/12/Gambar-Yamaha-MX-King-150-Facelift.jpg"
            ))

            list.add(Motor(
                nama = "Nmax",
                pabrikan = "Yamaha",
                keterangan = " Banyak yang memprediksi Yamaha akan meluncurkan New Yamaha NMAX agar motor ini tetap eksis melawan Honda PCX. Kami yakin Yamaha akan melakukan perubahan cukup signifikan pada NMAX generasi terbaru. Meski belum ada bocoran seperti apa bentuknya, namun yang pasti motor terbaru 2020 ini akan tetap memiliki desain bongsor yang menjadi ciri khas Maxi Skuter buatan Yamaha. ",
                url = "https://www.otomotifer.com/motor-terbaru-2019-di-indonesia/",
                gambar = "https://www.otomotifer.com/wp-content/uploads/2018/12/Gambar-Yamaha-NMAX-Facelift.jpg"
            ))

            list.add(Motor(
                nama = "PCX Electric",
                pabrikan = "Honda",
                keterangan = " Setelah sukses memasarkan Honda PCX ABS dan Honda PCX Hybrid, maka selanjutnya Honda akan meluncurkan PCX Electric yang sepenuhnya menggunakan mesin litrik. Kemungkinan besar harga motor terbaru 2020 ini akan sangat mahal, karena dibekali motor listrik yang bertenaga dan pastinya sangat canggih. Fitur-fiturnya juga keren, seperti Keyless, Riding Mode, dll.",
                url = "https://www.otomotifer.com/motor-terbaru-2019-di-indonesia/",
                gambar = "https://www.otomotifer.com/wp-content/uploads/2018/12/Honda-PCX-Electric.jpg"
            ))

            list.add(Motor(
                nama = "R25",
                pabrikan = "Yamaha",
                keterangan = " Belum lama ini Yamaha meluncurkan R25 generasi terbaru dengan menawarkan perubahan pada sisi desain dan penambahan beberapa fitur baru, seperti headlamp LED, upside down, dan speedometer full digital. Motor sport ini bisa menjadi alternatif bagi masbro yang mencari motor terbaru 2020, karena harganya lebih murah dari Honda CBR250RR maupun Kawasaki Ninja 250.",
                url = "https://www.otomotifer.com/motor-terbaru-2019-di-indonesia/",
                gambar = "https://www.otomotifer.com/wp-content/uploads/2018/11/Gambar-Motor-Sport-Yamaha-R25-Movistar.jpg"
            ))

            list.add(Motor(
                nama = "Wr150",
                pabrikan = "Yamaha",
                keterangan = " Yamaha dikabarkan akan meluncukan WR150 untuk menantang Kawasaki KLX 150 dan Honda CRF150L. Ketiganya merupakan motor Dual Purpose yang legal digunakan di jalan raya maupun track offroad. Kami yakin pecinta otomotif tanah air tak akan ragu membelinya asalkan harga Yamaha WR150 tak terlalu mahal. Paling tidak motor ini dipasarkan pada rentang harga 30 Jutaan, sehingga bisa bersaing melawan KLX 150 dan CRF150L.",
                url = "https://www.otomotifer.com/motor-terbaru-2019-di-indonesia/",
                gambar = "https://www.otomotifer.com/wp-content/uploads/2018/12/Gambar-Yamaha-WR150.jpg"
            ))

            list.add(Motor(
                nama = "Z250",
                pabrikan = "Kawasaki",
                keterangan = " Kawasaki baru saja meluncurkan Z400 di ajang EICMA 2018. Kami yakin Kawasaki Z400 tidak akan dipasarkan di Indonesia, dan digantikan oleh Kawasaki Z250 dengan desain sama persis. Desainnya berubah drastis dibandingkan Z250 generasi sebelumnya. Motor 2 Silinder 250cc tersebut terlihat lebih agresif dan semakin ergonomis yang membuatnya lebih nyaman dikendarai. ",
                url = "https://www.otomotifer.com/motor-terbaru-2019-di-indonesia/",
                gambar = "https://www.otomotifer.com/wp-content/uploads/2018/12/Gambar-New-Kawasaki-Z250.jpg"
            ))


            return list
        }
}