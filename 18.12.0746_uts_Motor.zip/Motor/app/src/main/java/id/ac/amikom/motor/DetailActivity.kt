package id.ac.amikom.motor

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.activity_detail.*
import kotlinx.android.synthetic.main.item_motor.view.*

class DetailActivity : AppCompatActivity() {
    var motor: Motor? = null
    lateinit var motorDao: MotorDao
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        motorDao= AppDatabase.getInstance(this).motorDao()
        motor = intent.getParcelableExtra<Motor>(MainActivity.KEY_MOTOR)
        populate(motor)

        supportActionBar?.apply {
            setDisplayHomeAsUpEnabled(true)
        }
    }
    fun populate(motor: Motor?){
        motor?.apply {
            Glide.with(this@DetailActivity).load(gambar).into(detailImage)
            detailName.text = nama
            detailPabrikan.text = pabrikan
            detailKeterangan.text = keterangan
            detailUrl.text = url
        }

        supportActionBar?.apply {
            title = motor?.nama
            subtitle = motor?.pabrikan
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.menuEdit -> {
                val intent = Intent(this, AddEditActivity::class.java)
                intent.putExtra(MainActivity.KEY_MOTOR, motor)
                startActivityForResult(intent, MainActivity.REQUEST_EDIT)
            }
            R.id.menuRemove -> {
                AlertDialog.Builder(this)
                    .setMessage("Apakah Anda Yakin Akan Menghapus Ini?")
                    .setPositiveButton("ya") {_,_ ->
                        motor?.apply {
                            motorDao.Delete(this)
                        }
                        Toast.makeText(this,"Data sudah berhasil di hapus", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                    .setNegativeButton("tidak", null)
                    .show()
            }
            else -> {
                finish()
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == MainActivity.REQUEST_EDIT && resultCode == Activity.RESULT_OK && data != null)
            motor =  data.getParcelableExtra(MainActivity.KEY_MOTOR)
        populate(motor)
        motor?.apply {
            motorDao.Update(this)
        }
        Toast.makeText(this,"Data sudah berhasil di edit", Toast.LENGTH_SHORT).show()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.detail_menu, menu)
        return super.onCreateOptionsMenu(menu)
    }
}