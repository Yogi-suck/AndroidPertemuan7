package id.ac.amikom.motor

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import kotlinx.android.synthetic.main.activity_add_edit.*

class AddEditActivity : AppCompatActivity() {
    var motor: Motor? = null
    companion object{
        const val REQUEST_IMAGE = 400
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_edit)
        motor= intent.getParcelableExtra(MainActivity.KEY_MOTOR)
        supportActionBar?.apply {
            title = if (motor == null) "Add Motor" else "Edit Motor"
            motor?.apply {
                subtitle= nama
            }
            setDisplayHomeAsUpEnabled(true)
        }
        motor?.apply {
            addEditNama.setText(nama)
            addEditPabrikan.setText(pabrikan)
            addEditKeterangan.setText(keterangan)
            addEditUrl.setText(url)
            addEditGambar.setText(gambar)
        }
        buttonBrowse.setOnClickListener {
            val intent = Intent()
            intent.setType("image/*")
            intent.setAction(Intent.ACTION_GET_CONTENT)
            startActivityForResult(Intent.createChooser(intent, "Pilih Gambar"), REQUEST_IMAGE)

        }
        buttonSave.setOnClickListener {
            if (motor == null) motor = Motor()
            motor?.apply {
                nama = addEditNama.text.toString()
                pabrikan = addEditPabrikan.text.toString()
                keterangan = addEditKeterangan.text.toString()
                url = addEditUrl.text.toString()
                gambar = addEditGambar.text.toString()
            }
            val intent = Intent()
            intent.putExtra(MainActivity.KEY_MOTOR, motor)
            setResult(Activity.RESULT_OK, intent)
            finish()

        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE && resultCode == Activity.RESULT_OK && data != null){
            val imageUrl = data.data?.toString()
            addEditGambar.setText(imageUrl)
        }
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        finish()
        return super.onContextItemSelected(item)
    }
}