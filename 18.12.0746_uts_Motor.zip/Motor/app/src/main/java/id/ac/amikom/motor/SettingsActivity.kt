package id.ac.amikom.motor

import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.widget.addTextChangedListener
import kotlinx.android.synthetic.main.activity_settings.*

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        supportActionBar?.apply {
            title = "Settings"
            setDisplayHomeAsUpEnabled(true)
        }

        val appSettingPref: SharedPreferences = getSharedPreferences("AppSettingPrefs",0)
        val SharedPrefEdit: SharedPreferences.Editor = appSettingPref.edit()
        val isNightModeOn:Boolean = appSettingPref.getBoolean("NightMode",false)

        val sharedPref = SharedPref(this)
        settingsGrid.isChecked = sharedPref.gridLayout
        settingsGrid.setOnCheckedChangeListener { buttonView, isChecked ->
            sharedPref.gridLayout = isChecked
        }

        settingsPabrikan.isChecked= sharedPref.pabrikan
        settingsPabrikan.setOnCheckedChangeListener { buttonView, isChecked ->
            sharedPref.pabrikan= isChecked
        }

        settingsAppName.setText(sharedPref.appName)
        settingsAppName.addTextChangedListener {
            sharedPref.appName = it.toString()
        }

        settingsColumn.setText(sharedPref.column.toString())
        settingsColumn.addTextChangedListener {
            var cols = if (it.toString().length==0) 1 else it.toString().toInt()
            cols =  if (cols > 3){
                3
            } else if (cols > 1){
                1
            } else{
                cols
            }
            sharedPref.column = cols
        }

        settingsNamaGambar.isChecked=sharedPref.namaGambar
        settingsNamaGambar.setOnCheckedChangeListener { buttonView, isChecked ->
            sharedPref.namaGambar= isChecked
        }

        settingsGambar.isChecked=sharedPref.gambar
        settingsGambar.setOnCheckedChangeListener { buttonView, isChecked ->
            sharedPref.gambar= isChecked
        }

        settingsCardview.isChecked=sharedPref.cardview
        settingsCardview.setOnCheckedChangeListener { buttonView, isChecked ->
            sharedPref.cardview= isChecked
        }

        if (isNightModeOn){
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        }else{
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
        darkmode.setOnClickListener {
            if (isNightModeOn) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                SharedPrefEdit.putBoolean("NightMode", false)
                SharedPrefEdit.apply()
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                SharedPrefEdit.putBoolean("NightMode", true)
                SharedPrefEdit.apply()
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        finish()
        return super.onOptionsItemSelected(item)
    }
}