package id.ac.amikom.motor

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.activity_settings.view.*
import kotlinx.android.synthetic.main.item_motor.view.*

class MotorAdapter (var list: List<Motor>, val sharedPref: SharedPref) : RecyclerView.Adapter<MotorAdapter.ViewHolder>() {

    var onItemClickListener: ((Motor) -> Unit)? = null

    class ViewHolder (itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind (motor: Motor) {
            with(itemView) {
                Glide.with(this).load(motor.gambar).into(itemImage)
                itemNama.text = motor.nama
                itemPabrikan.text = motor.pabrikan
            }
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_motor, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val motor = list.get(position)
        holder.bind(motor)
        holder.itemView.setOnClickListener {
            onItemClickListener?.invoke(motor)
        }
        holder.itemView.itemPabrikan.visibility = if (sharedPref.pabrikan) View.VISIBLE else View.GONE
        holder.itemView.itemNama.visibility = if (sharedPref.namaGambar) View.VISIBLE else View.GONE
        holder.itemView.itemImage.visibility = if (sharedPref.gambar) View.VISIBLE else View.GONE
        holder.itemView.cardview.visibility = if (sharedPref.cardview) View.VISIBLE else View.GONE
    }
}