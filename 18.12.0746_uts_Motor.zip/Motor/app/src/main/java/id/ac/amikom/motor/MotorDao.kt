package id.ac.amikom.motor

import androidx.room.*

@Dao
interface MotorDao {
    @Insert
    fun Insert(motor: Motor)

    @Update
    fun Update(motor: Motor)

    @Delete
    fun Delete(motor: Motor)

    @Query("SELECT * FROM motor")
    fun selectAll() : List<Motor>

    @Query("SELECT * FROM motor WHERE id=:id")
    fun select(id : Int) : Motor
}